﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad5
{
    public class SpolkaGieldowa
    {
        public string nazwa { get; set; }
        public double wycena { get; set; }
        public DateTime dataNotowania { get; set; }

    }
}